// config/database.js
module.exports = {
  'url' : 'mongodb://taylor:10q6w71e@novus.modulusmongo.net:27017/idIvo8de'
};