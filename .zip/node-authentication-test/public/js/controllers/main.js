angular.module('userController', [])

    .controller('mainController', function($scope, $http, Users) {
       Users.get()
        .success(function(data) {
            $scope.todos = data;
            $scope.loading = false;
        });
    });
