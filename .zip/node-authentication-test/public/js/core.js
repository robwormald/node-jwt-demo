angular.module('getHired', ['userController', 'userService']);
